export { default } from "./(front-office)/page";
